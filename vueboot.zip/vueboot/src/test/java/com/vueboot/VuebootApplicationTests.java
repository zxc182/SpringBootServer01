package com.vueboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VuebootApplicationTests {

	@Test
	void contextLoads() {
	}

}
